<?php
class WPBakeryShortCode_PGL_Productcategory extends WPBakeryShortCode {
	
}