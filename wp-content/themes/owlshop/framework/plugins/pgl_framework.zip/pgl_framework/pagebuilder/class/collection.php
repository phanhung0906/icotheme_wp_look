<?php
class WPBakeryShortCode_PGL_Collection extends WPBakeryShortCode {
	
}