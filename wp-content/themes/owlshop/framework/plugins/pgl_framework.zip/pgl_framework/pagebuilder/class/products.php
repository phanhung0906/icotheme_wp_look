<?php
class WPBakeryShortCode_PGL_Products extends WPBakeryShortCode {
	
}