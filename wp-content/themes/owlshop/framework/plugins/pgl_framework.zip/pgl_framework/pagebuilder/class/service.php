<?php
class WPBakeryShortCode_PGL_Service extends WPBakeryShortCode {
	
}