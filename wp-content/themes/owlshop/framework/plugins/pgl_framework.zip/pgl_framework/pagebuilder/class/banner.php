<?php
class WPBakeryShortCode_PGL_Banner extends WPBakeryShortCode {
	
}