<?php
class WPBakeryShortCode_PGL_Brands extends WPBakeryShortCode {
	
}