<?php
class WPBakeryShortCode_PGL_Testimonials extends WPBakeryShortCode {
	
}