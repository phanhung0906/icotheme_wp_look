<?php
class WPBakeryShortCode_PGL_Box_Content extends WPBakeryShortCode {
	
}