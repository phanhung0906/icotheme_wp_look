<?php
class WPBakeryShortCode_PGL_Product_Deals extends WPBakeryShortCode {
	
}